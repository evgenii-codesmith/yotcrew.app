"use client"

import { useState } from "react"
import Image from "next/image"
import { Search, MapPin, DollarSign, Clock, Building2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination"

// Mock job data
const jobs = [
  {
    id: 1,
    title: "Senior Frontend Developer",
    company: "TechCorp Inc.",
    location: "San Francisco, CA",
    salary: "$120k - $160k",
    type: "Full-time",
    experience: "Senior",
    description:
      "We're looking for a senior frontend developer to join our team and help build the next generation of web applications.",
    logo: "/placeholder.svg?height=60&width=60",
    posted: "2 days ago",
  },
  {
    id: 2,
    title: "Product Manager",
    company: "StartupXYZ",
    location: "New York, NY",
    salary: "$100k - $140k",
    type: "Full-time",
    experience: "Mid-level",
    description:
      "Join our product team to drive innovation and deliver exceptional user experiences across our platform.",
    logo: "/placeholder.svg?height=60&width=60",
    posted: "1 day ago",
  },
  {
    id: 3,
    title: "UX Designer",
    company: "Design Studio",
    location: "Remote",
    salary: "$80k - $110k",
    type: "Contract",
    experience: "Mid-level",
    description: "Create beautiful and intuitive user experiences for our clients' digital products and services.",
    logo: "/placeholder.svg?height=60&width=60",
    posted: "3 days ago",
  },
  {
    id: 4,
    title: "Backend Engineer",
    company: "CloudTech Solutions",
    location: "Austin, TX",
    salary: "$110k - $150k",
    type: "Full-time",
    experience: "Senior",
    description: "Build scalable backend systems and APIs that power our cloud-based applications.",
    logo: "/placeholder.svg?height=60&width=60",
    posted: "1 week ago",
  },
  {
    id: 5,
    title: "Data Scientist",
    company: "Analytics Pro",
    location: "Seattle, WA",
    salary: "$130k - $170k",
    type: "Full-time",
    experience: "Senior",
    description: "Analyze complex datasets and build machine learning models to drive business insights.",
    logo: "/placeholder.svg?height=60&width=60",
    posted: "4 days ago",
  },
  {
    id: 6,
    title: "Junior Developer",
    company: "CodeCraft",
    location: "Chicago, IL",
    salary: "$60k - $80k",
    type: "Full-time",
    experience: "Entry-level",
    description: "Start your career in software development with our supportive team and mentorship program.",
    logo: "/placeholder.svg?height=60&width=60",
    posted: "5 days ago",
  },
  {
    id: 7,
    title: "DevOps Engineer",
    company: "Infrastructure Inc.",
    location: "Denver, CO",
    salary: "$105k - $135k",
    type: "Full-time",
    experience: "Mid-level",
    description: "Manage and optimize our cloud infrastructure and deployment pipelines.",
    logo: "/placeholder.svg?height=60&width=60",
    posted: "6 days ago",
  },
  {
    id: 8,
    title: "Marketing Specialist",
    company: "Growth Agency",
    location: "Los Angeles, CA",
    salary: "$70k - $90k",
    type: "Part-time",
    experience: "Mid-level",
    description: "Drive marketing campaigns and help our clients achieve their growth objectives.",
    logo: "/placeholder.svg?height=60&width=60",
    posted: "1 week ago",
  },
  {
    id: 9,
    title: "Mobile App Developer",
    company: "AppWorks",
    location: "Miami, FL",
    salary: "$95k - $125k",
    type: "Full-time",
    experience: "Mid-level",
    description: "Develop native mobile applications for iOS and Android platforms.",
    logo: "/placeholder.svg?height=60&width=60",
    posted: "3 days ago",
  },
]

export default function Component() {
  const [currentPage, setCurrentPage] = useState(1)
  const jobsPerPage = 6
  const totalPages = Math.ceil(jobs.length / jobsPerPage)

  const startIndex = (currentPage - 1) * jobsPerPage
  const currentJobs = jobs.slice(startIndex, startIndex + jobsPerPage)

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-3xl font-bold text-gray-900">JobBoard</h1>
            <Button>Post a Job</Button>
          </div>

          {/* Filters */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
            <div className="lg:col-span-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input placeholder="Search jobs, companies..." className="pl-10" />
              </div>
            </div>

            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Job Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="full-time">Full-time</SelectItem>
                <SelectItem value="part-time">Part-time</SelectItem>
                <SelectItem value="contract">Contract</SelectItem>
                <SelectItem value="freelance">Freelance</SelectItem>
              </SelectContent>
            </Select>

            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Location" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Locations</SelectItem>
                <SelectItem value="remote">Remote</SelectItem>
                <SelectItem value="san-francisco">San Francisco</SelectItem>
                <SelectItem value="new-york">New York</SelectItem>
                <SelectItem value="austin">Austin</SelectItem>
                <SelectItem value="seattle">Seattle</SelectItem>
              </SelectContent>
            </Select>

            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Experience" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Levels</SelectItem>
                <SelectItem value="entry">Entry-level</SelectItem>
                <SelectItem value="mid">Mid-level</SelectItem>
                <SelectItem value="senior">Senior</SelectItem>
                <SelectItem value="lead">Lead</SelectItem>
              </SelectContent>
            </Select>

            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Newest</SelectItem>
                <SelectItem value="oldest">Oldest</SelectItem>
                <SelectItem value="salary-high">Salary: High to Low</SelectItem>
                <SelectItem value="salary-low">Salary: Low to High</SelectItem>
                <SelectItem value="relevance">Relevance</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <p className="text-gray-600">
            Showing {startIndex + 1}-{Math.min(startIndex + jobsPerPage, jobs.length)} of {jobs.length} jobs
          </p>
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-600">View:</span>
            <Button variant="outline" size="sm">
              Grid
            </Button>
            <Button variant="ghost" size="sm">
              List
            </Button>
          </div>
        </div>

        {/* Job Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {currentJobs.map((job) => (
            <Card key={job.id} className="hover:shadow-lg transition-shadow duration-200">
              <CardHeader className="pb-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <Image
                      src={job.logo || "/placeholder.svg"}
                      alt={`${job.company} logo`}
                      width={48}
                      height={48}
                      className="rounded-lg"
                    />
                    <div>
                      <h3 className="font-semibold text-lg leading-tight">{job.title}</h3>
                      <p className="text-gray-600 flex items-center gap-1">
                        <Building2 className="h-4 w-4" />
                        {job.company}
                      </p>
                    </div>
                  </div>
                  <Badge variant={job.type === "Full-time" ? "default" : "secondary"}>{job.type}</Badge>
                </div>
              </CardHeader>

              <CardContent className="pb-4">
                <div className="space-y-2 mb-4">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <MapPin className="h-4 w-4" />
                    {job.location}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <DollarSign className="h-4 w-4" />
                    {job.salary}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Clock className="h-4 w-4" />
                    {job.posted}
                  </div>
                </div>

                <p className="text-gray-700 text-sm line-clamp-3">{job.description}</p>

                <div className="mt-3">
                  <Badge variant="outline">{job.experience}</Badge>
                </div>
              </CardContent>

              <CardFooter className="pt-0">
                <div className="flex gap-2 w-full">
                  <Button className="flex-1">Apply Now</Button>
                  <Button variant="outline" size="icon">
                    <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
                      />
                    </svg>
                  </Button>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>

        {/* Pagination */}
        <div className="flex justify-center">
          <Pagination>
            <PaginationContent>
              <PaginationItem>
                <PaginationPrevious
                  href="#"
                  onClick={(e) => {
                    e.preventDefault()
                    if (currentPage > 1) setCurrentPage(currentPage - 1)
                  }}
                  className={currentPage === 1 ? "pointer-events-none opacity-50" : ""}
                />
              </PaginationItem>

              {[...Array(totalPages)].map((_, i) => (
                <PaginationItem key={i + 1}>
                  <PaginationLink
                    href="#"
                    onClick={(e) => {
                      e.preventDefault()
                      setCurrentPage(i + 1)
                    }}
                    isActive={currentPage === i + 1}
                  >
                    {i + 1}
                  </PaginationLink>
                </PaginationItem>
              ))}

              <PaginationItem>
                <PaginationNext
                  href="#"
                  onClick={(e) => {
                    e.preventDefault()
                    if (currentPage < totalPages) setCurrentPage(currentPage + 1)
                  }}
                  className={currentPage === totalPages ? "pointer-events-none opacity-50" : ""}
                />
              </PaginationItem>
            </PaginationContent>
          </Pagination>
        </div>
      </main>
    </div>
  )
}
