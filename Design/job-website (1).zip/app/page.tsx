import Component from "../job-website"

export default function Page() {
  return <Component />
}
